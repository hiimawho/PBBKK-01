<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	{{$name}}
    {{$pass}}
</body>
</html>